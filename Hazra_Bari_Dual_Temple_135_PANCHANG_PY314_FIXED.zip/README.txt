HAZRA BARI DUAL TEMPLE — 8900.py
PANCHANG PYTHON-3.14 FIX

Main file: 8900.py

Important:
The previous version depended on pysweph, but the deployed Streamlit environment was Python 3.14.8 and repeatedly reported ModuleNotFoundError: swisseph. This build removes that deployment blocker and uses PyEphem 4.2.1, which publishes CPython 3.14 Linux wheels.

Requirements:
- streamlit>=1.40,<2
- ephem==4.2.1
- streamlit-autorefresh>=1.0.1,<2

Panchang backend:
- PyEphem astronomical Sun/Moon positions and rise/set
- Lahiri sidereal conversion
- Durgapur coordinates: 23.51583 N, 87.30801 E, 100 m
- Asia/Kolkata (IST)
- Dynamic Tithi, Nakshatra, Yoga, Karana and Paksha
- Sunrise, sunset, moonrise and moonset
- No hard-coded daily Panchang values

This build intentionally does NOT attempt runtime pip installation.
