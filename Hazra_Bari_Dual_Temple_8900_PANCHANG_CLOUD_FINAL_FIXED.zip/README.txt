HAZRA BARI DUAL TEMPLE - 890.py

PANCHANG CLOUD FIX

IMPORTANT:
This version removes the faulty runtime pip-install recovery that caused
UnboundLocalError/CalledProcessError on Streamlit Cloud.

The Panchang engine uses pysweph==2.10.3.6 and imports it as:
    import swisseph as swe

DEPLOYMENT REQUIREMENT:
Use Python 3.13 for this Streamlit Cloud app.
The pysweph 2.10.3.6 release provides Linux wheels for CPython 3.13.
Your previous Cloud traceback showed Python 3.14, where the matching wheel
is not provided.

In Streamlit Community Cloud:
1. Open the app's deployment settings.
2. Use Advanced settings.
3. Select Python 3.13.
4. Save/redeploy.
5. Ensure the repository contains 890.py and this requirements.txt.
6. Set the entrypoint to 890.py.

If the app is already deployed on Python 3.14, Streamlit Cloud requires a
new deployment to change the Python version.

The application does NOT install Python packages at runtime.
This avoids cloud build/runtime conflicts and misleading secondary errors.

PANCHANG:
- Durgapur, West Bengal
- IST / Asia-Kolkata
- Lahiri sidereal calculations
- Tithi, Nakshatra, Yoga, Karana, Paksha
- Sunrise, sunset, Panchang-day moonrise and moonset
- No hard-coded daily Panchang values
- Astronomical moonrise remains available for the weekday-theme boundary

All existing dual-temple features in 890.py are retained.
