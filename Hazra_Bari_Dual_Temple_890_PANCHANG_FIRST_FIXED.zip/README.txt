HAZRA BARI DUAL TEMPLE — 890.py
================================

Main Streamlit entrypoint: 890.py

PANCHANG CLOUD FIX
------------------
The Durgapur Panchang uses Swiss Ephemeris through pysweph==2.10.3.6.
The dependency is declared in requirements.txt. 890.py also has a one-time
runtime recovery: if swisseph is missing from an already-created environment,
it attempts to install pysweph==2.10.3.6 and reload the module before rendering
the Panchang error state.

The code uses:
- Durgapur coordinates: 23.51583 N, 87.30801 E, altitude 100 m
- Asia/Kolkata (IST)
- Lahiri sidereal calculations
- Dynamic Tithi, Nakshatra, Yoga and Karana
- Sunrise, sunset, Panchang-day moonrise and moonset
- Astronomical moonrise for the separate weekday-theme boundary
- No hard-coded daily Panchang values

IMPORTANT STREAMLIT CLOUD DEPLOYMENT
------------------------------------
Keep BOTH files in the repository root (or together beside the entrypoint):
    890.py
    requirements.txt

If the app was previously deployed with an older dependency environment,
commit the updated requirements.txt and reboot/redeploy the app so Cloud
rebuilds the dependency environment.
